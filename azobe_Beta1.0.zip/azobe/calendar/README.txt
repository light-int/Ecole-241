A Pen created at CodePen.io. You can find this one at https://codepen.io/B8bop/pen/GhCAb.

 Calendar I made for a little project.